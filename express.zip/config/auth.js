module.exports = function (req, res, next) {
    //Do your session checking...
    next();
};